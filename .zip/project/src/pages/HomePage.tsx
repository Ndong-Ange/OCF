import React from 'react';
import Hero from '../components/Hero';

const HomePage = () => {
  return (
    <div className="bg-black">
      <Hero />
    </div>
  );
};

export default HomePage;